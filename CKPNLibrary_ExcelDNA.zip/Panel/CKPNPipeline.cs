using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using CKPNLibrary.Helpers;
using CKPNLibrary.Modules;
using ExcelDna.Integration;
using Excel = Microsoft.Office.Interop.Excel;

namespace CKPNLibrary.Panel
{
    /// <summary>
    /// Menjalankan rangkaian perhitungan CKPN dari Panel dengan progres per langkah.
    ///
    /// CARA KERJA
    ///   Setiap langkah dijadwalkan terpisah. Di antara dua langkah ada JEDA
    ///   singkat (timer ~250 ms) sebelum langkah berikutnya diantrekan lewat
    ///   ExcelAsyncUtil.QueueAsMacro. Selama jeda itu Excel benar-benar idle:
    ///   antrean pesan Windows dikosongkan, termasuk klik "Batalkan" dari
    ///   panel yang tertahan selama modul berjalan. Tanpa jeda ini, antrean
    ///   makro berikutnya bisa dieksekusi LEBIH DULU daripada pesan batal,
    ///   sehingga pembatalan saat PD Net Flow tidak pernah terbaca.
    ///   Modul perhitungan sendiri tetap berjalan sinkron seperti dari VBA.
    ///
    /// TAMPILAN EXCEL SAAT MODUL BERJALAN
    ///   Modul panjang (PD Net Flow membuka 12–13 file) memblok thread utama
    ///   lebih dari 5 detik. Windows lalu "ghosting": jendela Excel diputihkan
    ///   dan berjudul "(Not Responding)", walaupun proses berjalan normal.
    ///   DisableProcessWindowsGhosting mematikan efek itu untuk proses Excel,
    ///   sehingga tampilan tetap seperti saat CKPN Individu berjalan.
    ///
    /// LOGIKA HITUNG TIDAK DIDUPLIKASI
    ///   Pipeline memanggil kelas modul yang SAMA dengan CKPNFunctions
    ///   (CKPNIndividu, CKPNPDNetFlow, PDMigration, LGD..., RefreshSummary),
    ///   dengan parameter yang dibaca ParameterMaster persis seperti makro VBA.
    ///
    /// WORKBOOK AKTIF
    ///   Modul lama memakai _app.ActiveWorkbook. Sebelum setiap langkah, workbook
    ///   aplikasi diaktifkan ulang, sehingga modul selalu menulis ke workbook
    ///   yang benar walaupun user sempat mengklik workbook lain.
    /// </summary>
    internal static class CKPNPipeline
    {
        // ------------------------------------------------------------
        // Definisi langkah (urutan = urutan eksekusi)
        // ------------------------------------------------------------
        internal class Langkah
        {
            public string Id, Nama, SheetDitulis;
            public Action<Excel.Application, ParameterCKPN> Jalankan;
        }

        public static readonly Langkah[] SemuaLangkah =
        {
            new Langkah { Id = "individu",  Nama = "CKPN Individu",            SheetDitulis = "A. CKPN - INDV",            Jalankan = JalankanIndividu  },
            new Langkah { Id = "netflow",   Nama = "PD Net Flow",              SheetDitulis = "B1.PD-Net Flow",            Jalankan = JalankanNetFlow   },
            new Langkah { Id = "migration", Nama = "PD Migration",             SheetDitulis = "B2.PD-Migration, state PD Migration", Jalankan = JalankanMigration },
            new Langkah { Id = "lgder",     Nama = "LGD Expected Recoveries",  SheetDitulis = "B3.LGD-ER",                 Jalankan = JalankanLgdEr     },
            new Langkah { Id = "lgdcs",     Nama = "LGD Collateral Shortfall", SheetDitulis = "B4.LGD-CS MACET",           Jalankan = JalankanLgdCs     },
            new Langkah { Id = "summary",   Nama = "Refresh Summary & PPKA",   SheetDitulis = "Summary",                   Jalankan = JalankanSummary   },
        };

        /// <summary>
        /// Langkah khusus mode setahun sekali (Tahap 5e): menulis PD &amp; LGD Desember tahun lalu
        /// (acuan) ke sheet kolektif. Tidak tampil di tab Manual; disisipkan setelah CKPN Individu
        /// bila run memakai acuan, menggantikan Net Flow, Migration, LGD ER, dan LGD CS.
        /// </summary>
        private static readonly Langkah LangkahAcuan = new Langkah
        {
            Id = "acuan", Nama = "PD & LGD acuan Desember", SheetDitulis = AcuanTahunan.SheetKol, Jalankan = JalankanAcuan
        };
        private static AcuanTahunan.Acuan _acuan;

        /// <summary>
        /// Langkah otomatis Tahap 5g: ambil Overview Data (OS, EAD, NPF, PPKA per KC dari template
        /// Master!D14) dan simpan sebagai snapshot periode di database. Disisipkan di awal run hanya
        /// bila snapshot periode Master!C4 belum ada atau file template berubah, dan hanya untuk user
        /// pengirim. Kegagalannya tidak menggagalkan perhitungan CKPN (dicatat sebagai peringatan).
        /// </summary>
        private static readonly Langkah LangkahOverview = new Langkah
        {
            Id = "overview", Nama = "Data overview (OS, EAD, NPF)", SheetDitulis = "— (database, sheet tidak diubah)", Jalankan = JalankanOverview
        };
        private static string _alasanOverview;

        /// <summary>
        /// Tahap 8 (mode per kantor): salin file sumber dan buang baris kantor di luar grup (Master!H8), lalu
        /// ganti path sumber langkah berikutnya dengan salinan itu. Modul perhitungan tidak berubah.
        /// </summary>
        private static readonly Langkah LangkahLingkup = new Langkah
        {
            Id = "lingkup", Nama = "Saring sumber per grup", SheetDitulis = "— (salinan file sumber di folder lokal)", Jalankan = JalankanLingkup
        };

        /// <summary>Keputusan acuan pada MulaiGrup terakhir (untuk BatchGrup/panel); null = tidak relevan.</summary>
        public static string CatatanAcuan { get; private set; }

        /// <summary>Id langkah hitung (dipakai ParameterMaster untuk error umum).</summary>
        public static IEnumerable<string> IdLangkahHitung
        {
            get { foreach (var l in SemuaLangkah) yield return l.Id; }
        }

        // ------------------------------------------------------------
        // State run (hanya diakses di thread utama Excel)
        // ------------------------------------------------------------
        public static bool SedangBerjalan { get; private set; }

        /// <summary>
        /// Callback sekali pakai setelah run berakhir (dipakai BatchGrup untuk lanjut ke grup
        /// berikutnya). Null untuk run biasa, sehingga hitung manual/per grup tidak berubah.
        /// </summary>
        internal static Action<Excel.Application, string> SetelahSelesai;

        /// <summary>True hanya saat sebuah langkah sedang dieksekusi oleh pipeline.</summary>
        public static bool DiDalamLangkah { get; private set; }

        private static bool           _mintaBatal;
        private static List<Langkah>  _antrian;
        private static int            _indeks;
        private static ParameterCKPN  _param;
        private static Excel.Workbook _wbApp;
        private static Stopwatch      _swTotal;
        private static List<Dictionary<string, object>> _hasilLangkah;
        private static string         _langkahAktif = "";

        /// <summary>
        /// Dipanggil Protection.CekProteksi: tolak perintah dari tombol VBA saat
        /// pipeline panel sedang berjalan (di sela dua langkah), supaya dua
        /// perhitungan tidak menulis ke sheet yang sama secara bersamaan.
        /// </summary>
        public static bool TolakPanggilanLuar()
        {
            return SedangBerjalan && !DiDalamLangkah;
        }

        public static object Status()
        {
            return new Dictionary<string, object>
            {
                { "berjalan", SedangBerjalan },
                { "langkahAktif", _langkahAktif },
                { "ke", _indeks + 1 },
                { "dari", _antrian == null ? 0 : _antrian.Count }
            };
        }

        public static void MintaBatal()
        {
            if (SedangBerjalan) _mintaBatal = true;
        }

        // ------------------------------------------------------------
        // Mulai — dipanggil di konteks makro (QueueAsMacro dari PanelBridge)
        // ------------------------------------------------------------
        /// <returns>null bila berhasil dimulai; selain itu pesan penolakan.</returns>
        /// <param name="sumberLog">label sumber di log proses, mis. "Panel · Grup Murabahah" (bawaan "Panel · Manual")</param>
        public static string Mulai(Excel.Application app, IList<string> idDipilih, bool terapkanPenyesuaian = true,
                                   string sumberLog = null, AcuanTahunan.Acuan acuan = null)
        {
            if (SedangBerjalan) return "Perhitungan lain sedang berjalan.";

            Excel.Workbook wb = PanelBridge.CariWorkbookAplikasi(app);
            if (wb == null) return "Workbook aplikasi CKPN tidak sedang terbuka.";

            // Baca ulang Master tepat sebelum jalan — nilai yang ditampilkan panel
            // bisa sudah basi bila user mengubah Master setelah menekan "Periksa".
            ParameterCKPN p = ParameterMaster.Baca(wb);

            // Tahap 7: edisi Lite selalu menghitung seluruh segmen KC0600–KC1100 — centang Master disesuaikan
            string catatanLisensi = null;
            try
            {
                catatanLisensi = Lisensi.CentangSeluruhKC(wb);
                if (catatanLisensi != null) p = ParameterMaster.Baca(wb);
            }
            catch (Exception ex) { return "Edisi Lite: centang KC0600–KC1100 di Master gagal diubah otomatis (" + PesanError(ex) + "). Centang manual lalu ulangi."; }
            string tolakLisensi = Lisensi.TolakHitung(p.KC);
            if (tolakLisensi != null) return tolakLisensi;

            // Tahap 8: lingkup mode perhitungan. Mode akad → saringan Master!H8 dikosongkan (sisa mode lain).
            // Mode kantor → seluruh KC0600–KC1100 dicentang; file sumber disaring per sandi kantor (langkah "lingkup").
            try
            {
                bool berubah = false;
                if (ModeHitung.Aktif.Utama)
                {
                    Excel.Worksheet mF = ParameterMaster.CariSheet(wb, "Master");
                    if (ModeHitung.BacaFilterMentah(mF).Length > 0) { ModeHitung.BersihkanFilterBilaAkad(wb); berubah = true; }
                }
                else if (p.KC.Length != ModeHitung.SemuaKC.Length)
                {
                    ParameterMaster.SetKCDicentang(wb, ModeHitung.SemuaKC);
                    berubah = true;
                }
                if (berubah) p = ParameterMaster.Baca(wb);
            }
            catch (Exception ex) { return "Lingkup mode " + ModeHitung.Aktif.NamaPendek + " gagal disiapkan di Master: " + PesanError(ex); }

            var pilih = new HashSet<string>(idDipilih ?? new string[0], StringComparer.OrdinalIgnoreCase);
            var antrian = new List<Langkah>();
            var masalah = new List<string>();
            foreach (var l in SemuaLangkah)
            {
                if (!pilih.Contains(l.Id)) continue;
                if (!p.Siap(l.Id)) masalah.Add(l.Nama + ": " + string.Join("; ", p.Error[l.Id].ToArray()));
                antrian.Add(l);
                if (l.Id == "individu" && acuan != null) antrian.Add(LangkahAcuan);   // acuan ditulis setelah Individu
            }
            if (acuan != null && !pilih.Contains("individu")) return "Acuan PD & LGD hanya dapat dipakai bersama CKPN Individu.";
            if (antrian.Count == 0) return "Belum ada langkah yang dipilih.";
            if (masalah.Count > 0) return "Parameter belum lengkap:\n- " + string.Join("\n- ", masalah.ToArray());

            // Tahap 5g: snapshot Overview periode ini diambil dulu bila belum tersimpan / template berubah
            _alasanOverview = null;
            try
            {
                DateTime tglOv;
                string alasanOv;
                if (ParameterMaster.BacaTanggalLaporan(wb, out tglOv) &&
                    Data.PenjelasanCKPN.OverviewPerluDiambil(tglOv.ToString("yyyy-MM-dd"), ParameterMaster.BacaPathTemplate(wb), out alasanOv))
                {
                    _alasanOverview = alasanOv;
                    antrian.Insert(0, LangkahOverview);
                }
            }
            catch (Exception ex) { CatatanLog.Tulis("Cek snapshot overview gagal: " + PesanError(ex)); }

            // Tahap 8: mode per kantor — saring sumber sebelum langkah hitung pertama (sesudah overview)
            if (!ModeHitung.Aktif.Utama && FilterLingkup.Dari(app) != null &&
                antrian.Exists(x => x.Id == "individu" || x.Id == "netflow" || x.Id == "migration" || x.Id == "lgdcs" || x.Id == "summary"))
            {
                int pos = antrian.Count > 0 && antrian[0].Id == "overview" ? 1 : 0;
                antrian.Insert(pos, LangkahLingkup);
            }

            _wbApp        = wb;
            _param        = p;
            _acuan        = acuan;
            _antrian      = antrian;
            _indeks       = -1;          // -1 = langkah pemeriksaan proteksi
            _mintaBatal   = false;
            _swTotal      = Stopwatch.StartNew();
            _hasilLangkah = new List<Dictionary<string, object>>();
            SedangBerjalan = true;
            Pemberitahu.MulaiModePanel();
            if (catatanLisensi != null) Pemberitahu.Info("Edisi Lite", catatanLisensi);
            // Penyesuaian manual tersimpan (Individu I/J, LGD CS) diterapkan di
            // dalam modul. Bisa dimatikan per run untuk melihat hasil sistem murni.
            Data.Penyesuaian.Aktif = terapkanPenyesuaian;
            MatikanGhostingSekali();
            try { app.Cursor = Excel.XlMousePointer.xlWait; } catch { }

            var daftar = new List<object>();
            foreach (var l in antrian)
                daftar.Add(new Dictionary<string, object> { { "id", l.Id }, { "nama", l.Nama } });

            CatatanLog.Tulis("=== RUN MULAI oleh " + Environment.UserName + " · periode " + p.BulanLaporan +
                             " · mode " + ModeHitung.Aktif.Id + (ModeHitung.Aktif.Utama ? "" : " [" + p.KodeGrup + "]") +
                             " · KC " + p.KCList + " · langkah: " + string.Join(",", Ids(antrian)));

            // Log proses (Tahap 5): semua catatan modul selama run ini memakai id jalan yang sama
            DateTime tglLog;
            string periodeLog = ParameterMaster.BacaTanggalLaporan(wb, out tglLog) ? tglLog.ToString("yyyy-MM-dd") : "";
            LogProses.MulaiJalan(string.IsNullOrEmpty(sumberLog) ? "Panel · Manual" : sumberLog, periodeLog);
            var namaLangkah = new List<string>();
            foreach (var l in antrian) namaLangkah.Add(l.Nama);
            LogProses.Catat("Panel", "Jalan mulai", LogProses.Info, LogProses.R()
                .Tambah("Mode", ModeHitung.Aktif.Nama)
                .TambahBila(!ModeHitung.Aktif.Utama, "Lingkup", ModeHitung.LabelKode(p.KodeGrup))
                .Tambah("KC", p.KCList)
                .Tambah("Bulan laporan", p.BulanLaporan)
                .Tambah("Langkah", string.Join(", ", namaLangkah.ToArray()))
                .Tambah("Penyesuaian tersimpan", terapkanPenyesuaian ? "diterapkan" : "tidak diterapkan (hasil sistem murni)")
                .Tambah("Signifikansi individu", Signifikansi.Label(Signifikansi.Baca(wb), ParameterMaster.BacaTopN(wb)))
                .Tambah("Ruang lingkup KC1000", RuangLingkup.LabelTahunMaster(wb))
                .Tambah("Ruang lingkup KC1100", RuangLingkup.LabelKC1100)
                .TambahBila(acuan != null, "PD & LGD", acuan == null ? null : "acuan " + acuan.Label + " (Net Flow, Migration, LGD ER, LGD CS dilewati)"));
            PanelBridge.Siarkan("runMulai", new Dictionary<string, object>
            {
                { "langkah", daftar }, { "periode", p.BulanLaporan }, { "kc", p.KCList },
                { "kodeGrup", p.KodeGrup }, { "labelKode", ModeHitung.LabelKode(p.KodeGrup) },
                { "penyesuaian", terapkanPenyesuaian }
            });

            JadwalkanBerikut();
            return null;
        }

        // ------------------------------------------------------------
        // Eksekusi satu langkah, lalu jadwalkan langkah berikutnya
        // ------------------------------------------------------------
        private static void LangkahBerikut()
        {
            var app = (Excel.Application)ExcelDnaUtil.Application;

            if (_mintaBatal) { Akhiri(app, "dibatalkan", null); return; }

            // ---- Langkah 0: verifikasi proteksi file (sekali per run) ----
            if (_indeks == -1)
            {
                _langkahAktif = "proteksi";
                bool ok;
                DiDalamLangkah = true;
                try
                {
                    AktifkanWorkbookAplikasi();
                    ok = Protection.CekProteksi(app);   // menampilkan dialog sendiri bila gagal
                }
                catch (Exception ex) { Akhiri(app, "gagal", "Pemeriksaan proteksi: " + ex.Message); return; }
                finally { DiDalamLangkah = false; }

                if (!ok) { Akhiri(app, "gagal", "Pemeriksaan proteksi file gagal (lihat dialog yang muncul)."); return; }

                // PD & LGD dihitung penuh pada run ini → acuan lama (bila ada) tidak boleh terpakai lagi.
                // Sekalian memastikan rumus mode setahun terpasang di sheet kolektif (Tahap 5e).
                if (_acuan == null && _antrian.Exists(x => x.Id == "netflow" || x.Id == "migration" || x.Id == "lgder" || x.Id == "lgdcs"))
                {
                    try { AcuanTahunan.Kosongkan(_wbApp); }
                    catch (Exception ex) { CatatanLog.Tulis("Kosongkan acuan PD & LGD gagal: " + PesanError(ex)); }
                }
                // Tahap 5h: PD & LGD ABA tahunan (⚙ Pengaturan) → Summary C21:C23
                try { AktifkanWorkbookAplikasi(); ParameterAba.Terapkan(_wbApp); }
                catch (Exception ex)
                {
                    CatatanLog.Tulis("Parameter ABA gagal diterapkan: " + PesanError(ex));
                    LogProses.Catat("Parameter ABA", "Summary C21:C23", LogProses.Peringatan, LogProses.R().Tambah("Error", PesanError(ex)));
                }
                // Ruang lingkup tunggakan KC1000 (⚙ Pengaturan) → Master!H11, dibaca modul saat membaca KC1000
                try { AktifkanWorkbookAplikasi(); RuangLingkup.Terapkan(_wbApp); }
                catch (Exception ex)
                {
                    Akhiri(app, "gagal", "Tidak dapat menulis ruang lingkup KC1000 ke Master!" + RuangLingkup.Sel + ": " + PesanError(ex));
                    return;
                }
                _indeks = 0;
                JadwalkanBerikut();
                return;
            }

            if (_indeks >= _antrian.Count) { Akhiri(app, "selesai", null); return; }

            Langkah l = _antrian[_indeks];
            _langkahAktif = l.Id;
            PanelBridge.Siarkan("langkahMulai", new Dictionary<string, object>
            {
                { "id", l.Id }, { "nama", l.Nama }, { "ke", _indeks + 1 }, { "dari", _antrian.Count }
            });
            try { app.StatusBar = "Panel CKPN: " + l.Nama + " (" + (_indeks + 1) + "/" + _antrian.Count + ")…"; } catch { }

            var sw = Stopwatch.StartNew();
            string error = null;

            // State aplikasi sama seperti makro VBA: layar & event dimatikan
            // selama modul berjalan, lalu dikembalikan ke kondisi semula.
            bool su = true, ev = true, da = true;
            Excel.XlCalculation calc = Excel.XlCalculation.xlCalculationAutomatic;
            try { su = app.ScreenUpdating; ev = app.EnableEvents; da = app.DisplayAlerts; calc = app.Calculation; } catch { }

            DiDalamLangkah = true;
            try
            {
                AktifkanWorkbookAplikasi();
                try
                {
                    app.ScreenUpdating = false;
                    app.Calculation    = Excel.XlCalculation.xlCalculationManual;
                    app.DisplayAlerts  = false;
                    app.EnableEvents   = false;
                }
                catch { }

                l.Jalankan(app, _param);
            }
            catch (Exception ex)
            {
                error = PesanError(ex);
            }
            finally
            {
                DiDalamLangkah = false;
                try { app.EnableEvents = ev; }   catch { }
                try { app.DisplayAlerts = da; }  catch { }
                try { app.Calculation = calc; }  catch { }
                try { app.ScreenUpdating = su; } catch { }
            }
            sw.Stop();

            var hasil = new Dictionary<string, object>
            {
                { "id", l.Id }, { "nama", l.Nama }, { "durasiMs", sw.ElapsedMilliseconds },
                { "ok", error == null }, { "error", error }
            };
            _hasilLangkah.Add(hasil);
            PanelBridge.Siarkan("langkahSelesai", hasil);
            CatatanLog.Tulis("  " + l.Nama + " · " + (error == null ? "OK" : "GAGAL: " + error) +
                             " · " + (sw.ElapsedMilliseconds / 1000.0).ToString("0.0") + " dtk");
            LogProses.Catat("Panel", "Langkah " + l.Nama, error == null ? LogProses.OK : LogProses.Gagal, LogProses.R()
                .Tambah("Durasi", (sw.ElapsedMilliseconds / 1000.0).ToString("0.0", LogProses.Id) + " dtk")
                .TambahBila(error != null, "Error", error));

            if (error != null) { Akhiri(app, "gagal", l.Nama + ": " + error); return; }

            _indeks++;
            JadwalkanBerikut();
        }

        /// <summary>
        /// Hitung satu grup dari tab Periode: centang KC di Master diubah sesuai
        /// grup, lalu seluruh langkah dijalankan (penyesuaian tersimpan diterapkan).
        /// </summary>
        /// <param name="pakaiAcuan">mode setahun sekali, laporan Jan–Nov: pakai PD &amp; LGD Desember tahun lalu
        /// dari database bila tersedia (bila tidak, grup dihitung penuh — lihat <see cref="CatatanAcuan"/>)</param>
        public static string MulaiGrup(Excel.Application app, string kodeKC, bool terapkanPenyesuaian, bool pakaiAcuan = false)
        {
            CatatanAcuan = null;
            if (SedangBerjalan) return "Perhitungan lain sedang berjalan.";
            Excel.Workbook wb = PanelBridge.CariWorkbookAplikasi(app);
            if (wb == null) return "Workbook aplikasi CKPN tidak sedang terbuka.";

            // Tahap 8: mode kantor — pastikan semua sandi kantor di template masuk susunan grup
            // (mode jenis penggunaan: unit tetap 1–3 dan isian kosong → Konsumsi, cukup cek susunan)
            ModeHitung.Mode mode = ModeHitung.Aktif;
            if (!mode.Utama)
            {
                string tolakCakupan;
                try { tolakCakupan = CekCakupanSandi(app, wb, kodeKC); }
                catch (Exception ex) { tolakCakupan = "Cakupan grup tidak dapat diperiksa: " + PesanError(ex); }
                if (tolakCakupan != null) return tolakCakupan;
            }
            try { ParameterMaster.SetKCDicentang(wb, ModeHitung.KCGrup(mode, kodeKC)); }
            catch (Exception ex) { return "Tidak dapat mengubah centang KC di Master: " + PesanError(ex); }
            try { ModeHitung.TulisFilter(wb, mode, mode.Utama ? "" : kodeKC); }
            catch (Exception ex) { return "Tidak dapat menulis lingkup grup ke Master!" + ModeHitung.SelFilter + ": " + PesanError(ex); }

            // Top-N debitur Individu mengikuti ketetapan grup di susunan tahunan (SOP) — ditulis ke Master!C10
            DateTime tgl;
            if (ParameterMaster.BacaTanggalLaporan(wb, out tgl))
            {
                // Tahap 9b: aturan signifikansi grup (ranking → Top-N ke C10; nominal → ambang ke H10)
                Data.Periode.Grup gs = Data.Periode.GrupSusunan(tgl.Year, kodeKC);
                if (gs != null && !gs.Nominal && gs.TopN.HasValue)
                {
                    try { ParameterMaster.SetTopN(wb, gs.TopN.Value); }
                    catch (Exception ex) { return "Tidak dapat menulis Top-N ke Master!C10: " + PesanError(ex); }
                }
                // Grup di luar susunan → H10 dikosongkan (Top-N Master!C10), supaya aturan grup sebelumnya tidak terbawa
                {
                    try { Signifikansi.Tulis(wb, gs == null ? Signifikansi.Ranking : gs.Signifikan, gs == null ? null : gs.Ambang); }
                    catch (Exception ex) { return "Tidak dapat menulis aturan signifikansi ke Master!" + Signifikansi.Sel + ": " + PesanError(ex); }
                }
            }

            string grupLog = kodeKC;
            DateTime tglG;
            if (ParameterMaster.BacaTanggalLaporan(wb, out tglG))
            {
                string nm;
                Data.Periode.TopNGrup(tglG.Year, kodeKC, out nm);
                if (!string.IsNullOrEmpty(nm)) grupLog = nm;
            }
            var semua = new List<string>(IdLangkahHitung);
            AcuanTahunan.Acuan acuan = null;
            int? thAcuan = null;
            if (pakaiAcuan && ParameterMaster.BacaTanggalLaporan(wb, out tglG) && AcuanTahunan.ModeTahunan(wb))
                thAcuan = AcuanTahunan.TahunAcuan(tglG);
            if (thAcuan.HasValue)
            {
                string masalahAcuan;
                try { acuan = AcuanTahunan.Cari(thAcuan.Value, kodeKC, out masalahAcuan); }
                catch (Exception ex) { masalahAcuan = PesanError(ex); }
                if (acuan != null)
                {
                    semua = new List<string> { "individu", "summary" };
                    CatatanAcuan = "PD & LGD acuan " + acuan.Label;
                }
                else CatatanAcuan = "Acuan Desember " + thAcuan.Value + " tidak tersedia (" + masalahAcuan + ") — dihitung penuh.";
            }
            return Mulai(app, semua, terapkanPenyesuaian,
                         (BatchGrup.Aktif ? "Panel · Semua grup · " : "Panel · Grup ") + grupLog, acuan);
        }

        /// <summary>
        /// Tahap 8 (mode kantor): tolak hitung grup bila ada sandi kantor di template periode ini yang tidak
        /// masuk grup mana pun di susunan tahun tersebut, atau ada baris pembiayaan tanpa sandi kantor —
        /// pembiayaan itu tidak akan masuk CKPN grup mana pun. Hasil pindai template di-cache per file.
        /// </summary>
        private static string CekCakupanSandi(Excel.Application app, Excel.Workbook wb, string kodeKC)
        {
            DateTime tgl;
            if (!ParameterMaster.BacaTanggalLaporan(wb, out tgl)) return "Tanggal laporan (Master!C4) belum diisi.";
            if (string.IsNullOrEmpty(ModeHitung.NormKode(ModeHitung.Aktif, kodeKC))) return "Grup tanpa " + ModeHitung.Aktif.NamaUnit + " tidak dapat dihitung.";
            List<Data.Periode.Grup> susunan = null;
            int sumber = 0;
            if (Data.Database.Ada)
                using (var con = Data.Database.Buka(false)) susunan = Data.Periode.Susunan(con, tgl.Year, out sumber);
            if (susunan == null)
                return "Susunan grup mode " + ModeHitung.Aktif.NamaPendek + " tahun " + tgl.Year +
                       " belum ditetapkan. Atur di ⚙ Pengaturan › Susunan grup.";

            var tercakup = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var g in susunan) foreach (var k in g.KodeKC.Split(',')) tercakup.Add(k);
            string[,] tetap = ModeHitung.UnitTetap(ModeHitung.Aktif);
            if (tetap != null)
            {
                // Mode unit tetap (jenis penggunaan / kelompok sektor): semua unit wajib masuk grup
                var kurang = new List<string>();
                for (int i = 0; i < tetap.GetLength(0); i++)
                    if (!tercakup.Contains(tetap[i, 0])) kurang.Add(tetap[i, 1]);
                string unit = ModeHitung.Aktif.NamaUnit;
                return kurang.Count == 0 ? null
                    : char.ToUpper(unit[0]) + unit.Substring(1) + " " + string.Join(", ", kurang.ToArray()) +
                      " belum masuk grup mana pun di susunan " + sumber + ".";
            }
            int kosong;
            string path = ParameterMaster.BacaPathTemplate(wb);
            var diTemplate = Data.SandiKantor.SandiTemplate(app, path, tgl.ToString("yyyy-MM-dd"), out kosong);
            try { wb.Activate(); } catch { }
            var luar = diTemplate.FindAll(x => !tercakup.Contains(x));
            if (luar.Count == 0 && kosong == 0) return null;

            var pesan = new List<string>();
            if (luar.Count > 0)
                pesan.Add("Sandi kantor " + string.Join(", ", luar.ToArray()) + " ada di template " + System.IO.Path.GetFileName(path) +
                          " tetapi belum masuk grup mana pun di susunan " + sumber + ". Tambahkan ke susunan grup (⚙ Pengaturan) lalu hitung ulang.");
            if (kosong > 0)
                pesan.Add(kosong + " baris pembiayaan di template tidak memiliki sandi kantor (kolom B). Lengkapi template terlebih dahulu.");
            LogProses.CatatPanel(tgl.ToString("yyyy-MM-dd"), "Mode per kantor", "Cakupan sandi kantor", LogProses.Gagal, LogProses.R()
                .Tambah("Template", path).TambahBila(luar.Count > 0, "Sandi di luar susunan", string.Join(", ", luar.ToArray()))
                .TambahBila(kosong > 0, "Baris tanpa sandi", kosong));
            return string.Join("\n", pesan.ToArray());
        }

        private static void Akhiri(Excel.Application app, string status, string error)
        {
            // Catat grup yang kini ada di workbook (dipakai tab Periode untuk status grup)
            if (status == "selesai" && _wbApp != null && _param != null)
            {
                try
                {
                    DateTime tgl;
                    if (ParameterMaster.BacaTanggalLaporan(_wbApp, out tgl))
                    {
                        Data.Periode.CatatHitung(tgl.ToString("yyyy-MM-dd"), _param.KodeGrup, Ids(_antrian));
                        // Tahap 7h: label lingkup kertas kerja → "belum disimpan"
                        LabelLingkup.Tulis(_wbApp, LabelLingkup.Info(tgl.ToString("yyyy-MM-dd"), _param.KodeGrup));
                    }
                }
                catch (Exception ex) { CatatanLog.Tulis("Catat konteks hitung gagal: " + ex.Message); }
            }

            var pesanModul = Pemberitahu.SelesaiModePanel();
            long durasi = _swTotal == null ? 0 : _swTotal.ElapsedMilliseconds;

            SedangBerjalan = false;
            DiDalamLangkah = false;
            Data.Penyesuaian.Aktif = true;   // tombol VBA selalu menerapkan penyesuaian
            _langkahAktif  = "";
            try { app.StatusBar = false; } catch { }
            try { app.Cursor = Excel.XlMousePointer.xlDefault; } catch { }
            if (_timer != null) { try { _timer.Stop(); } catch { } }

            CatatanLog.Tulis("=== RUN " + status.ToUpperInvariant() + " · " + (durasi / 1000.0).ToString("0.0") + " dtk" +
                             (error == null ? "" : " · " + error));
            LogProses.Catat("Panel", "Jalan " + status,
                status == "selesai" ? LogProses.OK : status == "dibatalkan" ? LogProses.Dilewati : LogProses.Gagal,
                LogProses.R()
                    .Tambah("Durasi", (durasi / 1000.0).ToString("0.0", LogProses.Id) + " dtk")
                    .Tambah("Langkah selesai", _hasilLangkah == null ? 0 : _hasilLangkah.Count)
                    .TambahBila(error != null, "Error", error));
            string jalanIni = LogProses.IdJalan;

            PanelBridge.Siarkan("runSelesai", new Dictionary<string, object>
            {
                { "status", status }, { "error", error }, { "durasiMs", durasi },
                { "langkah", _hasilLangkah }, { "pesan", pesanModul }
            });

            _antrian = null; _param = null; _wbApp = null; _acuan = null;

            var lanjut = SetelahSelesai;
            SetelahSelesai = null;
            if (lanjut != null)
            {
                // Lanjutan (mis. simpan otomatis Hitung semua grup) masih tercatat dengan id jalan ini
                try { lanjut(app, status); }
                catch (Exception ex) { CatatanLog.Tulis("Lanjutan setelah run gagal: " + ex.Message); }
            }
            // Tutup konteks — kecuali lanjutan sudah memulai run baru (grup berikutnya) dengan id sendiri
            if (LogProses.IdJalan == jalanIni) LogProses.SelesaiJalan();
        }

        // ------------------------------------------------------------
        // Penjadwalan langkah berikutnya dengan jeda
        // ------------------------------------------------------------
        private static System.Windows.Forms.Timer _timer;
        private const int JedaAntarLangkahMs = 250;

        /// <summary>
        /// Antrekan langkah berikutnya SETELAH jeda singkat. Timer WinForms
        /// berjalan di thread utama Excel (dibuat di sini, di konteks makro),
        /// jadi Tick selalu datang lewat loop pesan Excel — tepat setelah
        /// pesan-pesan yang tertunda (termasuk "batal") selesai diproses.
        /// </summary>
        private static void JadwalkanBerikut()
        {
            if (_timer == null)
            {
                _timer = new System.Windows.Forms.Timer { Interval = JedaAntarLangkahMs };
                _timer.Tick += (s, e) =>
                {
                    _timer.Stop();
                    ExcelAsyncUtil.QueueAsMacro(LangkahBerikut);
                };
            }
            _timer.Stop();
            _timer.Start();
        }

        [DllImport("user32.dll")]
        private static extern void DisableProcessWindowsGhosting();
        private static bool _ghostingMati;

        internal static void MatikanGhostingSekali()
        {
            if (_ghostingMati) return;
            try { DisableProcessWindowsGhosting(); } catch { }
            _ghostingMati = true;
        }

        private static void AktifkanWorkbookAplikasi()
        {
            try { if (_wbApp != null) _wbApp.Activate(); } catch { }
        }

        // ============================================================
        // Pemanggilan modul — cermin dari CKPNFunctions.cs
        // ============================================================
        private static void JalankanIndividu(Excel.Application app, ParameterCKPN p)
        {
            var x = p.Individu;
            new CKPNIndividu(app).Hitung(x.FilePath, x.TopN, x.NPF, x.Kol2, x.Restru, p.KC);
        }

        private static void JalankanNetFlow(Excel.Application app, ParameterCKPN p)
        {
            var x = p.NetFlow;
            // Pemecahan string identik dengan CKPNFunctions.IsiBucketPDNetflow
            // (RemoveEmptyEntries) supaya hasil sama persis dengan tombol VBA.
            var opt = StringSplitOptions.RemoveEmptyEntries;
            new CKPNPDNetFlow(app).IsiBucket(
                x.FilePaths.Split(new[] { '|' }, opt),
                x.BulanLabels.Split(new[] { '|' }, opt),
                x.RefDates.Split(new[] { '|' }, opt),
                x.TopN, p.KC);
        }

        private static void JalankanMigration(Excel.Application app, ParameterCKPN p)
        {
            var x = p.Migration;
            if (x.RunAll)
                new PDMigration(app).HitungSemua(x.AwalGab, x.AkhirGab, x.TglAwalGab, x.TglAkhirGab, x.TopN, p.KCList);
            else
                new PDMigration(app).Hitung(x.Triwulan, x.PathAwal, x.PathAkhir, x.TglAwal, x.TglAkhir, x.TopN, p.KCList);
        }

        private static void JalankanLgdEr(Excel.Application app, ParameterCKPN p)
        {
            new LGDExpectedRecoveries(app).Hitung(p.LgdEr.CurrYear, p.LgdEr.FilePathsStr, p.KCList);
        }

        private static void JalankanLgdCs(Excel.Application app, ParameterCKPN p)
        {
            new LGDCollateralShortfall(app).Hitung(p.LgdCs.FileConfigStr, p.LgdCs.Haircut, p.KCList);
        }

        private static void JalankanLingkup(Excel.Application app, ParameterCKPN p)
        {
            FilterLingkup f = FilterLingkup.Dari(app);
            if (f == null) return;
            var ids = new List<string>(Ids(_antrian));
            var sw = Stopwatch.StartNew();
            var ringkas = SumberLingkup.Siapkan(app, p, f, ids);
            AktifkanWorkbookAplikasi();
            LogProses.Catat("Mode " + ModeHitung.Aktif.NamaPendek.ToLowerInvariant(), "Saring sumber · " + f.Label, LogProses.OK, LogProses.R()
                .Tambah("File", ringkas.Count == 0 ? "-" : string.Join("; ", ringkas.ToArray()))
                .Tambah("Folder salinan", SumberLingkup.Folder)
                .Tambah("Durasi", (sw.ElapsedMilliseconds / 1000.0).ToString("0.0", LogProses.Id) + " dtk")
                .Tambah("Catatan", "Sheet KC0600–KC1100 disaring kolom " + f.Kolom + (ModeHitung.UnitPerKontrak(ModeHitung.Cari(f.ModeId))
                    ? " (baris agunan mengikuti kontraknya; kosong → " +
                      ModeHitung.NamaUnitKode(ModeHitung.Cari(f.ModeId), ModeHitung.UnitCadangan(ModeHitung.Cari(f.ModeId))) + ")" : "") +
                    "; KC0500 (ABA), KC2900, dan GB tidak diubah. LGD ER disaring lewat referensi hapus buku."));
        }

        private static void JalankanAcuan(Excel.Application app, ParameterCKPN p)
        {
            AcuanTahunan.Tulis(_wbApp ?? PanelBridge.CariWorkbookAplikasi(app), _acuan);
            Data.Penyesuaian.LewatiLgdCs("LGD memakai acuan " + _acuan.Label);
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("Mode setahun sekali: PD & LGD memakai versi " + _acuan.Label + " (status periode " + _acuan.Status + ").");
            sb.AppendLine("Net Flow, Migration, LGD ER, dan LGD CS tidak dihitung ulang.");
            sb.Append("LGD weighted " + (_acuan.Lgd.Value * 100).ToString("0.00", LogProses.Id) + "% · PD Migration Kol 1–5: ");
            for (int i = 0; i < 5; i++) sb.Append((i > 0 ? " / " : "") + (_acuan.PdMig[i].Value * 100).ToString("0.00", LogProses.Id) + "%");
            Pemberitahu.Info("PD & LGD acuan Desember", sb.ToString());
            LogProses.Catat("PD & LGD acuan", _acuan.Label, LogProses.OK, LogProses.R()
                .Tambah("Versi acuan", _acuan.RunId)
                .Tambah("Status periode acuan", _acuan.Status)
                .Tambah("LGD weighted", (_acuan.Lgd.Value * 100).ToString("0.00", LogProses.Id) + "%"));
        }

        // Tahap 5g: tidak melempar error — perhitungan CKPN tetap lanjut bila template overview gagal dibaca
        private static void JalankanOverview(Excel.Application app, ParameterCKPN p)
        {
            Excel.Workbook wb = _wbApp ?? PanelBridge.CariWorkbookAplikasi(app);
            try
            {
                var ov = new DataOverviewBuilder(app).UntukPanel(wb);
                string periode = Convert.ToString(ov["periode"]);
                bool ok = Data.PenjelasanCKPN.SimpanOverview(periode, ov, "Otomatis saat hitung · " + Convert.ToString(ov["fileTemplate"]));
                var total = ov["total"] as Dictionary<string, object>;
                LogProses.Catat("Overview data", periode, ok ? LogProses.OK : LogProses.Peringatan, LogProses.R()
                    .Tambah("Alasan", _alasanOverview)
                    .Tambah("File", ov["fileTemplate"])
                    .TambahBila(total != null, "Total OS", total == null ? null : total["totalOS"])
                    .TambahBila(total != null, "NPF", total == null || total["npf"] == null ? null :
                        (Convert.ToDouble(total["npf"]) * 100).ToString("0.00", LogProses.Id) + "%")
                    .TambahBila(!ok, "Keterangan", "snapshot tidak tersimpan ke database"));
            }
            catch (Exception ex)
            {
                string msg = PesanError(ex);
                CatatanLog.Tulis("  Data overview gagal (perhitungan tetap lanjut): " + msg);
                LogProses.Catat("Overview data", "Master!D14", LogProses.Peringatan, LogProses.R()
                    .Tambah("Alasan", _alasanOverview).Tambah("Error", msg));
                Pemberitahu.Info("Data overview belum tersimpan",
                    "Overview Data (OS, EAD, NPF per KC) gagal dibaca dari template Master!D14: " + msg + "\n" +
                    "Perhitungan CKPN tetap dilanjutkan. Muat ulang dari Ringkasan setelah template diperbaiki.");
            }
        }

        private static void JalankanSummary(Excel.Application app, ParameterCKPN p)
        {
            new RefreshSummary(app).Refresh(p.Summary.FilePath, p.KCList);
            // Tahap 5h: bila modul Refresh Summary menulis ulang C21:C23, parameter tahunan tetap berlaku
            ParameterAba.Terapkan(_wbApp ?? PanelBridge.CariWorkbookAplikasi(app));
        }

        // ------------------------------------------------------------
        private static string PesanError(Exception ex)
        {
            // Exception COM sering membungkus penyebab asli di InnerException.
            Exception e = ex;
            while (e is System.Reflection.TargetInvocationException && e.InnerException != null) e = e.InnerException;
            return e.Message;
        }

        private static IEnumerable<string> Ids(List<Langkah> l)
        {
            foreach (var x in l) yield return x.Id;
        }
    }
}
