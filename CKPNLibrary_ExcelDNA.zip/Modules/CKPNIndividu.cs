using System;
using System.Collections.Generic;
using CKPNLibrary.Helpers;
using CKPNLibrary.Models;
using CKPNLibrary.Styling;
using Excel = Microsoft.Office.Interop.Excel;

namespace CKPNLibrary.Modules
{
    internal class CKPNIndividu
    {
        private readonly Excel.Application _app;

        // Password proteksi sheet hasil "A. CKPN - INDV".
        // Sheet dibuka di awal perhitungan, lalu dikunci ulang di finally.
        private const string PW_SHEET = "HaiiWhatt??";

        public CKPNIndividu(Excel.Application app)
        {
            _app = app ?? throw new ArgumentNullException("app");
        }

        public void Hitung(
            string filePath, int topN,
            bool flagNPF, bool flagKol2, bool flagRestru,
            string[] sheetKCList)
        {
            var wsOut = CariSheet(_app.ActiveWorkbook, "A. CKPN - INDV");
            if (wsOut == null)
                throw new InvalidOperationException("Sheet 'A. CKPN - INDV' tidak ditemukan.");

            Excel.Workbook wbSrc = null;
            try
            {
                // Buka proteksi sheet output bila sedang terkunci, agar bisa ditulisi.
                // Dilakukan di DALAM try supaya blok finally dijamin mengunci ulang.
                BukaProteksiSheet(wsOut);

                wbSrc = _app.Workbooks.Open(filePath, UpdateLinks: 0, ReadOnly: true);

                var dictCIF = new Dictionary<string, CIFData>(StringComparer.OrdinalIgnoreCase);
                foreach (var shName in sheetKCList)
                {
                    SheetSpec spec;
                    try { spec = SheetSpec.Buat(shName); }
                    catch { continue; }
                    ExcelHelper.BacaSheetKC(wbSrc, spec, dictCIF);
                }

                var dictRestru = flagRestru
                    ? ExcelHelper.BacaDaftarRestru(wbSrc, "GB0500", "D")
                    : new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                wbSrc.Close(false);
                wbSrc = null;

                if (dictCIF.Count == 0)
                    throw new InvalidOperationException("Tidak ada data piutang yang ditemukan.");

                var listCIF = new List<CIFData>(dictCIF.Values);
                SortHelper.SortDescByTotalOS(listCIF, 0, listCIF.Count - 1);

                if (topN < 1) topN = 10;
                if (topN > listCIF.Count) topN = listCIF.Count;
                // Tahap 9b: metode nominal (Master!H10) → semua CIF dengan baki debet ≥ ambang.
                // listCIF sudah terurut menurun; ranking tetap min(Top-N, jumlah CIF).
                topN = Signifikansi.Batas(topN, listCIF.Count, i => listCIF[i].TotalOS);

                BersihkanOutput(wsOut);

                // Flag kriteria tambahan: tunggakan > 7 s.d. 30 hari (Master!F13).
                bool flag7Hari = CekFlag7Hari();

                // Penyesuaian tersimpan: nilai agunan (I) & biaya penjualan (J) — Tahap 3a
                CKPNLibrary.Data.Penyesuaian.MulaiIndividu();

                int baris = 5;
                for (int rCif = 0; rCif < topN; rCif++)
                {
                    var cifData = listCIF[rCif];
                    foreach (var kontrak in cifData.Kontrak.Values)
                    {
                        baris++;
                        string adaPN = TentukanPN(kontrak, dictRestru, flagNPF, flagKol2, flagRestru, flag7Hari);
                        TulisBaris(wsOut, baris, rCif + 1, cifData.CIF, cifData.Nama, kontrak, adaPN);
                        CKPNLibrary.Data.Penyesuaian.TerapkanIndividu(wsOut, baris, kontrak.NoKontrak, kontrak.Jaminan);
                        // Tahap 6: bukti objektif penurunan nilai untuk memo CKPN Individu
                        CKPNLibrary.Data.Penyesuaian.CatatBuktiIndividu(kontrak.NoKontrak, kontrak.Kualitas, kontrak.HariTunggakan,
                            flagRestru && dictRestru.Contains(kontrak.NoKontrak.Trim()), adaPN,
                            flagNPF, flagKol2, flagRestru, flag7Hari);
                    }
                }

                int totalRows = baris - 5;
                if (totalRows > 0)
                    StyleHelper.StyleTabelCKPN(wsOut, totalRows);

                // Setelah styling, agar warna penanda penyesuaian tidak tertimpa
                CKPNLibrary.Data.Penyesuaian.SelesaiIndividu(wsOut);

                // Atur kunci sel SEBELUM sheet dikunci ulang di finally:
                //   I & J bebas diedit user, K terkunci + formula disembunyikan.
                AturKunciKolomOutput(wsOut, baris);

                // ================= Audit Log =================
                var noaPerKC = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                foreach (var shName in sheetKCList)
                    noaPerKC[shName] = 0;
                foreach (var cd in dictCIF.Values)
                    foreach (var k in cd.Kontrak.Values)
                    {
                        string kc = (k.SheetKC ?? "").Trim();
                        if (noaPerKC.ContainsKey(kc)) noaPerKC[kc]++;
                        else noaPerKC[kc] = 1;
                    }

                int totalNOA = 0;
                foreach (var v in noaPerKC.Values) totalNOA += v;

                double totalOS = 0;
                for (int r = 0; r < topN; r++) totalOS += listCIF[r].TotalOS;

                try { TulisAuditLog(filePath, topN, totalNOA, totalOS, noaPerKC, sheetKCList); }
                catch { /* abaikan error logging */ }
                // =============================================

                // ============ MODE TAHUNAN (Master!D17) ============
                // Bulanan  -> tidak ada perubahan (logika di atas).
                // Tahunan  -> isi 'B. CKPN - KOL INDV'!U6:U19 dari file Master!D14,
                //             bucket outstanding per hari tunggakan, Top-N dikecualikan.
                if (CekModeTahunan())
                {
                    try { IsiBucketKolektifTahunan(filePath, topN, sheetKCList); }
                    catch { /* jangan gagalkan proses utama */ }
                }
                // ===================================================
            }
            finally
            {
                if (wbSrc != null) try { wbSrc.Close(false); } catch { }

                // Kunci kembali sheet output — selalu terproteksi setelah selesai,
                // apa pun yang terjadi selama perhitungan.
                KunciProteksiSheet(wsOut);
            }
        }

        // ----------------------------------------------------------------
        private static string TentukanPN(
            KontrakData kontrak, HashSet<string> dictRestru,
            bool flagNPF, bool flagKol2, bool flagRestru, bool flag7Hari)
        {
            // ---- Kriteria existing: Restrukturisasi → NPF → Kolektibilitas 2 ----
            if (flagRestru && dictRestru.Contains(kontrak.NoKontrak.Trim()))
                return "Ya";

            string hasil;
            switch (kontrak.Kualitas)
            {
                case 3: case 4: case 5: hasil = flagNPF  ? "Ya" : "Tidak"; break;
                case 2:                 hasil = flagKol2 ? "Ya" : "Tidak"; break;
                default:                hasil = "Tidak"; break;
            }

            // ---- Kriteria BARU (Master!F13 = "Ya"): tunggakan > 7 s.d. 30 hari ----
            // Hanya diterapkan pada debitur yang LOLOS ketiga kriteria di atas,
            // yaitu yang hasilnya masih "Tidak" (mis. Lancar, bukan NPF, bukan
            // Kol-2, bukan restrukturisasi). Bila hari tunggakan berada di rentang
            // (7, 30] → dianggap ada penurunan nilai (indikasi kenaikan risiko
            // kredit signifikan sebelum kolektibilitas turun).
            // Sifatnya hanya menambah: mengubah "Tidak" → "Ya", tidak sebaliknya.
            if (flag7Hari && hasil == "Tidak")
            {
                double hari = kontrak.HariTunggakan;
                if (hari > 7 && hari <= 30) hasil = "Ya";
            }

            return hasil;
        }

        // ----------------------------------------------------------------
        private static void TulisBaris(
            Excel.Worksheet wsOut, int baris, int nomorUrut,
            string cif, string nama, KontrakData kontrak, string adaPN)
        {
            Excel.Range colD = (Excel.Range)wsOut.Cells[baris, "D"];
            Excel.Range colF = (Excel.Range)wsOut.Cells[baris, "F"];
            colD.NumberFormat = "@";
            colF.NumberFormat = "@";

            ((Excel.Range)wsOut.Cells[baris, "B"]).Value2 = nomorUrut;
            ((Excel.Range)wsOut.Cells[baris, "C"]).Value2 = kontrak.SheetKC;
            ((Excel.Range)wsOut.Cells[baris, "D"]).Value2 = "'" + cif;
            ((Excel.Range)wsOut.Cells[baris, "E"]).Value2 = nama;
            ((Excel.Range)wsOut.Cells[baris, "F"]).Value2 = "'" + kontrak.NoKontrak;
            ((Excel.Range)wsOut.Cells[baris, "G"]).Value2 = kontrak.OS;
            ((Excel.Range)wsOut.Cells[baris, "H"]).Value2 = adaPN;
            ((Excel.Range)wsOut.Cells[baris, "I"]).Value2 = kontrak.Jaminan;

            ((Excel.Range)wsOut.Cells[baris, "K"]).Formula =
                "=IF(H" + baris + "=\"Ya\",MAX(0,G" + baris + "-(I" + baris + "-J" + baris + ")),0)";
        }

        // ----------------------------------------------------------------
        private static void BersihkanOutput(Excel.Worksheet wsOut)
        {
            Excel.Range lastCellB = (Excel.Range)wsOut.Cells[wsOut.Rows.Count, "B"];
            Excel.Range endCell   = (Excel.Range)lastCellB.End[Excel.XlDirection.xlUp];
            int lastOut = (int)endCell.Row;
            if (lastOut < 6) lastOut = 6;

            Excel.Range rng = (Excel.Range)wsOut.Range["B6", "K" + lastOut];
            rng.ClearContents();
            rng.ClearFormats();
            try { rng.UnMerge(); } catch { }
        }

        // ----------------------------------------------------------------
        // Atur kunci sel pada tabel hasil SEBELUM sheet diproteksi:
        //   - Kolom I (Nilai Jaminan) & J (Biaya Penjualan): Locked = false
        //     → tetap bisa diedit user meski sheet terproteksi.
        //   - Kolom K (Penurunan Nilai): Locked = true + FormulaHidden = true
        //     → terkunci dan formulanya tidak terlihat di formula bar.
        // Catatan: properti ini hanya berefek saat sheet dalam kondisi
        // terproteksi (dikunci di blok finally). ClearFormats di BersihkanOutput
        // sudah mengembalikan sel ke default (Locked = true) tiap run, sehingga
        // sisa baris lama tidak tertinggal dalam kondisi tidak terkunci.
        // ----------------------------------------------------------------
        private static void AturKunciKolomOutput(Excel.Worksheet wsOut, int barisAkhir)
        {
            if (barisAkhir < 6) return;   // tidak ada baris data

            // I & J: bebas diedit
            Excel.Range rngIJ = (Excel.Range)wsOut.Range["I6", "J" + barisAkhir];
            rngIJ.Locked        = false;
            rngIJ.FormulaHidden = false;

            // K: terkunci + formula disembunyikan
            Excel.Range rngK = (Excel.Range)wsOut.Range["K6", "K" + barisAkhir];
            rngK.Locked        = true;
            rngK.FormulaHidden = true;
        }

        // ----------------------------------------------------------------
        // Log proses (Tahap 5): ringkasan eksekusi — satu catatan per KC
        // + satu ringkasan. Dulu ditulis ke sheet "Audit Log"; kini ke file
        // teks lewat LogProses (lihat Panel CKPN › Riwayat › Log proses).
        // ----------------------------------------------------------------
        private void TulisAuditLog(
            string filePath, int topN, int totalNOA, double totalOS,
            Dictionary<string, int> noaPerKC, string[] sheetKCList)
        {
            foreach (var kc in sheetKCList)
            {
                int noa = noaPerKC.ContainsKey(kc) ? noaPerKC[kc] : 0;
                LogProses.Catat("CKPN Individu", kc, noa == 0 ? LogProses.Peringatan : LogProses.OK,
                    LogProses.R()
                        .TambahBila(noa == 0, "Keterangan", "Kosong / cek")
                        .Tambah("NOA kontrak", noa)
                        .Tambah("File", filePath));
            }
            LogProses.Catat("CKPN Individu", "Ringkasan", LogProses.OK, LogProses.R()
                .Tambah("Top-N", topN)
                .Tambah("OS Top-N", totalOS)
                .Tambah("NOA semua KC", totalNOA)
                .Tambah("KC", string.Join(",", sheetKCList))
                .Tambah("File", filePath));
        }

        // ================================================================
        // ============ MODE TAHUNAN: isi B. CKPN - KOL INDV!U6:U19 =======
        // ================================================================

        // -------- Switch Master!D17 --------
        private bool CekModeTahunan()
        {
            var ws = CariSheet(_app.ActiveWorkbook, "Master");
            if (ws == null) return false;
            var v = ((Excel.Range)ws.Range["D17"]).Value2;
            string s = (v ?? "").ToString();
            return s.IndexOf("setahun", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        // -------- Switch Master!F13: kriteria tunggakan > 7 s.d. 30 hari --------
        // "Ya"    -> aktifkan pengecekan tunggakan pada debitur yang lolos
        //            kriteria NPF/Kol-2/Restrukturisasi.
        // "Tidak" -> lewati (perilaku lama).
        private bool CekFlag7Hari()
        {
            var ws = CariSheet(_app.ActiveWorkbook, "Master");
            if (ws == null) return false;
            var v = ((Excel.Range)ws.Range["F13"]).Value2;
            string s = (v ?? "").ToString().Trim();
            return s.Equals("Ya", StringComparison.OrdinalIgnoreCase);
        }

        // -------- 14 bucket hari tunggakan -> baris kolom U (blok S5:X20) --------
        private static readonly (int Row, double Lo, double Hi)[] BucketsKol =
        {
            (6,  0,   0),      (7,  1,   30),    (8,  31,  60),    (9,  61,  90),
            (10, 91,  120),    (11, 121, 150),   (12, 151, 180),   (13, 181, 210),
            (14, 211, 240),    (15, 241, 270),   (16, 271, 300),   (17, 301, 330),
            (18, 331, 360),    (19, 361, 999999)
        };

        // -------- Isi U6:U19 (Baki Debet kolektif tahunan) --------
        private void IsiBucketKolektifTahunan(string filePath, int topN, string[] sheetKCList)
        {
            if (string.IsNullOrEmpty(filePath) || !System.IO.File.Exists(filePath))
                throw new InvalidOperationException("File sumber (Master!D14) tidak ditemukan: " + filePath);

            var wsKol = CariSheet(_app.ActiveWorkbook, "B. CKPN - KOL INDV");
            if (wsKol == null)
                throw new InvalidOperationException("Sheet 'B. CKPN - KOL INDV' tidak ditemukan.");

            var specs = new List<SheetSpec>();
            foreach (var shName in sheetKCList)
                try { specs.Add(SheetSpec.Buat(shName)); } catch { }
            if (specs.Count == 0)
                throw new InvalidOperationException("Tidak ada sheet KC valid.");

            Excel.Workbook srcWb = null;
            bool kolTerproteksi = false;
            try
            {
                // Buka proteksi sheet kolektif bila terkunci; dikunci ulang di finally.
                kolTerproteksi = BukaProteksiSheet(wsKol);

                srcWb = _app.Workbooks.Open(filePath, UpdateLinks: 0, ReadOnly: true);

                var allData = BacaSemueSheet(srcWb, specs);
                var setSkip = BangunSetExcludeTopN(allData, specs, topN);   // exclude Top-N

                foreach (var b in BucketsKol)
                {
                    double os = SumBucket(allData, specs, setSkip, b.Lo, b.Hi);
                    ((Excel.Range)wsKol.Cells[b.Row, "U"]).Value2 = os;
                }

                // Tahap 5e: OS per kualitas AKTUAL (populasi sama, Top-N dikecualikan) → U24:U28, dibaca C38:C42
                var osKual = new double[6];
                foreach (var spec in specs)
                {
                    if (!allData.ContainsKey(spec.SheetName)) continue;
                    foreach (var rec in allData[spec.SheetName])
                    {
                        if (!rec.Masuk || setSkip.Contains(spec.SheetName + "|" + rec.NoRek)) continue;
                        osKual[rec.Kual >= 1 && rec.Kual <= 5 ? rec.Kual : 0] += HitungOS(rec, spec.Mode);
                    }
                }
                for (int k = 1; k <= 5; k++) ((Excel.Range)wsKol.Cells[23 + k, "U"]).Value2 = osKual[k];
                ((Excel.Range)wsKol.Range["T29"]).Value2 = osKual[0] > 0 ? "Kualitas tidak dikenal (tidak masuk C38:C42)" : null;
                ((Excel.Range)wsKol.Range["U29"]).Value2 = osKual[0] > 0 ? (object)osKual[0] : null;

                // Acuan PD & LGD (Tahap 5e) hanya berlaku bila panel menuliskannya SETELAH langkah ini
                ((Excel.Range)wsKol.Range["Z3"]).ClearContents();
                ((Excel.Range)wsKol.Range["AB3"]).ClearContents();
            }
            finally
            {
                if (srcWb != null) try { srcWb.Close(false); } catch { }
                if (kolTerproteksi) KunciProteksiSheet(wsKol);
            }
        }

        // ================================================================
        // Mekanisme baca + exclude Top-N (identik dengan CKPNPDNetFlow)
        // ================================================================
        private class RowRecord
        {
            public string CIF, NoRek, Nama;
            public double Hari1, Nom1, Hari2, Nom2;
            public bool   Masuk;
            public int    Kual;   // Tahap 5e: kualitas 1–5 (0 = tidak dikenal)
        }

        private Dictionary<string, List<RowRecord>> BacaSemueSheet(
            Excel.Workbook srcWb, List<SheetSpec> specs)
        {
            var result = new Dictionary<string, List<RowRecord>>(StringComparer.OrdinalIgnoreCase);
            foreach (var spec in specs)
                result[spec.SheetName] = BacaSatuSheet(srcWb, spec);
            return result;
        }

        private List<RowRecord> BacaSatuSheet(Excel.Workbook wb, SheetSpec spec)
        {
            var list = new List<RowRecord>();
            if (!ExcelHelper.SheetAda(wb, spec.SheetName)) return list;

            var ws = (Excel.Worksheet)wb.Worksheets[spec.SheetName];
            int headerRow = spec.HeaderRow;
            int lastRow   = ExcelHelper.CariLastRow(ws, spec.ColCIF, headerRow);
            if (lastRow <= headerRow) return list;

            int dataStart = headerRow + 1;
            string[] cifArr  = ExcelHelper.BacaKolomString(ws, spec.ColCIF,   dataStart, lastRow);
            string[] rekArr  = ExcelHelper.BacaKolomString(ws, spec.ColNoRek, dataStart, lastRow);
            string[] namaArr = ExcelHelper.BacaKolomString(ws, spec.ColNama,  dataStart, lastRow);
            string[] kualArr = ExcelHelper.BacaKolomString(ws, spec.ColKualitas, dataStart, lastRow);   // Tahap 5e
            double[] h1Arr, n1Arr;
            double[] h2Arr = null, n2Arr = null;

            switch (spec.Mode)
            {
                case SheetMode.AF:
                    n1Arr = ExcelHelper.BacaKolomDouble(ws, spec.ColOS,     dataStart, lastRow);
                    h1Arr = ExcelHelper.BacaKolomDouble(ws, spec.ColHariAF, dataStart, lastRow);
                    break;
                case SheetMode.Tunggakan1:
                {
                    // KC1100 (ijarah): hari tunggakan gabungan ada di AK (ColHariPokok),
                    // nominal = tunggakan pokok (AL) + tunggakan ujroh/imbalan (AM).
                    // Karena aging pokok & ujroh menyatu di satu kolom (AK), keduanya
                    // selalu jatuh di bucket hari yang sama → cukup dijumlah ke Nom1.
                    // Dengan begitu SumBucket & HitungOS tidak perlu diubah.
                    h1Arr = ExcelHelper.BacaKolomDouble(ws, spec.ColHariPokok, dataStart, lastRow);
                    n1Arr = ExcelHelper.BacaKolomDouble(ws, spec.ColNomPokok,  dataStart, lastRow);
                    double[] ujrohArr = ExcelHelper.BacaKolomDouble(ws, spec.ColNomUjroh, dataStart, lastRow);
                    // Ruang lingkup KC1100: imbalan hanya kualitas 1–2; pokok semua kualitas
                    RuangLingkup.TerapkanKC1100(spec, ws, dataStart, lastRow, ujrohArr);
                    int mUj = Math.Min(n1Arr.Length, ujrohArr.Length);
                    for (int k = 0; k < mUj; k++) n1Arr[k] += ujrohArr[k];
                    break;
                }
                default: // Tunggakan2
                    h1Arr = ExcelHelper.BacaKolomDouble(ws, spec.ColHariPokok, dataStart, lastRow);
                    n1Arr = ExcelHelper.BacaKolomDouble(ws, spec.ColNomPokok,  dataStart, lastRow);
                    h2Arr = ExcelHelper.BacaKolomDouble(ws, spec.ColHariBasil, dataStart, lastRow);
                    n2Arr = ExcelHelper.BacaKolomDouble(ws, spec.ColNomBasil,  dataStart, lastRow);
                    // Ruang lingkup KC1000: pokok hanya kualitas Macet; bagi hasil sesuai ⚙ Pengaturan
                    RuangLingkup.TerapkanKC1000(spec, ws, dataStart, lastRow, n1Arr, n2Arr);
                    break;
            }

            for (int i = 0; i < cifArr.Length; i++)
            {
                string cif  = (cifArr[i]  ?? "").Trim();
                string rek  = (rekArr[i]  ?? "").Trim();
                string nama = (namaArr[i] ?? "").Trim();
                if (string.IsNullOrEmpty(cif) || string.IsNullOrEmpty(rek)) continue;

                double h1 = h1Arr[i], n1 = n1Arr[i];
                double h2 = h2Arr != null ? h2Arr[i] : 0;
                double n2 = n2Arr != null ? n2Arr[i] : 0;

                bool masuk;
                switch (spec.Mode)
                {
                    case SheetMode.AF:
                        masuk = true;
                        break;
                    case SheetMode.Tunggakan1:
                        masuk = !string.IsNullOrEmpty(nama);
                        break;
                    default: // Tunggakan2
                        masuk = !string.IsNullOrEmpty(nama);
                        break;
                }
                list.Add(new RowRecord { CIF=cif, NoRek=rek, Nama=nama, Hari1=h1, Nom1=n1, Hari2=h2, Nom2=n2, Masuk=masuk,
                                         Kual = NormKualitas(i < kualArr.Length ? kualArr[i] : "") });
            }
            return list;
        }

        private HashSet<string> BangunSetExcludeTopN(
            Dictionary<string, List<RowRecord>> allData,
            List<SheetSpec> specs, int topN)
        {
            var setSkip = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (!Signifikansi.Aktif(topN)) return setSkip;   // Tahap 9b: nominal tetap dijalankan

            var dictOSGlobal = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

            foreach (var spec in specs)
            {
                if (!allData.ContainsKey(spec.SheetName)) continue;
                foreach (var rec in allData[spec.SheetName])
                {
                    if (!rec.Masuk) continue;
                    double os = HitungOS(rec, spec.Mode);
                    if (dictOSGlobal.ContainsKey(rec.CIF))
                        dictOSGlobal[rec.CIF] += os;
                    else
                        dictOSGlobal[rec.CIF] = os;
                }
            }

            if (dictOSGlobal.Count == 0) return setSkip;

            var pairs = new List<SortHelper.CifOsPair>();
            foreach (var kv in dictOSGlobal)
                pairs.Add(new SortHelper.CifOsPair { CIF = kv.Key, OS = kv.Value });
            SortHelper.SortDescByOS(pairs, 0, pairs.Count - 1);

            int batas = Signifikansi.Batas(topN, pairs.Count, j => pairs[j].OS);   // Tahap 9b
            var topCIF = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int j = 0; j < batas; j++)
                topCIF.Add(pairs[j].CIF);

            foreach (var spec in specs)
            {
                if (!allData.ContainsKey(spec.SheetName)) continue;
                foreach (var rec in allData[spec.SheetName])
                    if (rec.Masuk && topCIF.Contains(rec.CIF))
                        setSkip.Add(spec.SheetName + "|" + rec.NoRek);
            }

            return setSkip;
        }

        private double SumBucket(
            Dictionary<string, List<RowRecord>> allData,
            List<SheetSpec> specs, HashSet<string> setSkip,
            double lo, double hi)
        {
            double total = 0;
            foreach (var spec in specs)
            {
                if (!allData.ContainsKey(spec.SheetName)) continue;
                foreach (var rec in allData[spec.SheetName])
                {
                    if (!rec.Masuk) continue;
                    if (setSkip.Contains(spec.SheetName + "|" + rec.NoRek)) continue;
                    switch (spec.Mode)
                    {
                        case SheetMode.AF:
                        case SheetMode.Tunggakan1:
                            if (rec.Hari1 >= lo && rec.Hari1 <= hi) total += rec.Nom1;
                            break;
                        case SheetMode.Tunggakan2:
                            if (rec.Hari1 >= lo && rec.Hari1 <= hi) total += rec.Nom1;
                            if (rec.Hari2 >= lo && rec.Hari2 <= hi) total += rec.Nom2;
                            break;
                    }
                }
            }
            return total;
        }

        // Tahap 5e: "1", "1 - Lancar", "05" → 1..5; selain itu 0
        private static int NormKualitas(string val)
        {
            if (string.IsNullOrWhiteSpace(val)) return 0;
            string s = val.Trim();
            int i = 0;
            while (i < s.Length && char.IsDigit(s[i])) i++;
            int n;
            return (i > 0 && int.TryParse(s.Substring(0, i), out n) && n >= 1 && n <= 5) ? n : 0;
        }

        private static double HitungOS(RowRecord rec, SheetMode mode)
        {
            switch (mode)
            {
                case SheetMode.AF:         return rec.Nom1;
                case SheetMode.Tunggakan1: return rec.Nom1;
                case SheetMode.Tunggakan2: return rec.Nom1 + rec.Nom2;
                default:                   return 0;
            }
        }

        // ----------------------------------------------------------------
        // ================================================================
        // PROTEKSI SHEET — buka di awal, kunci ulang di finally
        // ================================================================

        /// <summary>
        /// Membuka proteksi sheet bila sedang terproteksi. Melempar error yang
        /// jelas bila password tidak cocok, supaya penyebabnya tidak tersamar
        /// menjadi error 1004 generik saat penulisan sel.
        /// </summary>
        private bool BukaProteksiSheet(Excel.Worksheet ws)
        {
            if (ws == null) return false;

            bool terproteksi;
            try { terproteksi = ws.ProtectContents; }
            catch { return false; }

            if (!terproteksi) return false;   // memang tidak terkunci → tidak perlu apa-apa

            try
            {
                ws.Unprotect(PW_SHEET);
            }
            catch
            {
                throw new InvalidOperationException(
                    "Gagal membuka proteksi sheet '" + ws.Name + "'.\n\n" +
                    "Sheet terproteksi dengan password yang BERBEDA dari yang tertanam\n" +
                    "di aplikasi. Kunci ulang sheet dengan password yang benar, atau\n" +
                    "buka proteksinya manual sebelum menjalankan perhitungan.");
            }
            return true;
        }

        /// <summary>
        /// Mengunci sheet dengan proteksi standar (password tertanam).
        /// Dipanggil di finally agar sheet output selalu terproteksi setelah selesai.
        /// </summary>
        private void KunciProteksiSheet(Excel.Worksheet ws)
        {
            if (ws == null) return;
            try
            {
                ws.Protect(
                    Password:          PW_SHEET,
                    DrawingObjects:    true,
                    Contents:          true,
                    Scenarios:         true,
                    UserInterfaceOnly: false);
            }
            catch { /* abaikan; mis. sheet sudah terproteksi dgn password lain */ }
        }

        private static Excel.Worksheet CariSheet(Excel.Workbook wb, string name)
        {
            foreach (Excel.Worksheet sh in wb.Worksheets)
                if (string.Equals(sh.Name, name, StringComparison.OrdinalIgnoreCase))
                    return sh;
            return null;
        }
    }
}